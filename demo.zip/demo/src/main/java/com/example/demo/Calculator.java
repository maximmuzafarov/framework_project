package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Service;

@SpringBootApplication
@Service
public class Calculator {
	public static void main(String[] args)
	{
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(CalculatorCode.class);

		CalculatorCode calc = context.getBean("Calc", CalculatorCode.class);
		calc.calcCode();
	}
}
