package com.example.demo;

import org.springframework.stereotype.Component;
import java.util.Scanner;

import java.sql.SQLOutput;
@Component("Calc")
public class CalculatorCode {
    public void calcCode() {
        double num1;
        double num2;
        double ans;
        char op;
        Scanner reader = new Scanner(System.in);
        System.out.println("Введите два числа");
        num1 = reader.nextDouble();
        num2 = reader.nextDouble();
        System.out.print("\n+ - / *");
        op = reader.next().charAt(0);
        switch (op) {
            case '+':ans = num1 + num2;
            break;
            case '-':ans = num1 - num2;
            break;
            case '*':ans = num1 * num2;
                break;
            case '/':ans = num1 / num2;
                break;
            default: System.out.printf("Ошибка");
            return;
        }
        System.out.print("\n Результат\n");
        System.out.printf(num1 + " " + op + " " + num2 + " = " + ans);
    }
}
